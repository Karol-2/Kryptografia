KOD NAPISANY W PYTHON 3.11.2
program uruchamia sie za pomocą, np:
python main.py -c -e
python main.py -a -e
itp...

-c (szyfr Cezara),
-a (szyfr afiniczny),

-e (szyfrowanie),
-d (odszyfrowywanie),
-j (kryptoanaliza z tekstem jawnym),
-k (kryptoanaliza wyłącznie w oparciu o kryptogram)

1. Programy na początku wywołania sprawdzają obecność wymaganych plików
2. Na bieżąco są wyświetlane informacje o wczytaniu i zapisie danego pliku
3. W razie błędu jest wypisywana wiadomość i program konczy pracę
4. Kryptoanaliza wyłącznie w oparciu o kryptogram zapisuje wynik w decrypt.txt w formie:
klucz(a,b)
odszyfrowany kluczem tekst
